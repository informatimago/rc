;;; "c:/Users/PPBN02261/.emacs" -- Pascal J. Bourguignon's emacs startup files (Windows WOME).
;;; -*- mode:emacs-lisp;lexical-binding:t;coding:utf-8 -*-
;;; Commentary:
;;;   Hardcoded path to the modular rc/ tree which lives under MSYS2 HOME.
;;;   Synchronised counterpart of c:/msys64/home/PPBN02261/.emacs.
;;; Code:

(defvar WOME)
(defvar ROME)
(defvar MOME)
(defvar FROM)
(defvar RC)

(setq default-directory (expand-file-name "~/"))
(if (equal default-directory "c:/Users/PPBN02261/")
    (setq WOME "c:/Users/PPBN02261"
	  ROME "c;/Users/PPBN02261/AppData/Roaming"
	  MOME "c:/msys64/home/PPBN02261"
	  FROM 'MOME
	  RC (concat MOME "/rc"))
  (setq WOME "/c/Users/PPBN02261"
	ROME "/c/Users/PPBN02261/AppData/Roaming/"
	MOME "/home/PPBN02261"
	FROM 'MOME
	RC (concat MOME "/rc")))
(load (concat RC "/emacs.el"))

(set-frame-font "-outline-Lucida Console-regular-normal-normal-mono-25-*-*-*-c-*-iso10646-1")


;; Local Variables:
;; coding: utf-8
;; End:


