# -*- mode: shell-script;coding:utf-8 -*-
# .bashrc -- Windows Roaming HOME (C:/Users/PPBN02261/AppData/Roaming).
# Hardcoded path to the modular rc/ tree which lives under MSYS2 HOME.
# Synchronised counterpart of /c/msys64/home/PPBN02261/.bashrc.

export WOME='/c/users/PPBN02261'
export ROME='/c/users/PPBN02261/AppData/Roaming/'
export MOME='/home/PPBN02261'
export FROM=MOME
export RC="$MOME/rc"
source "$RC/bashrc"
